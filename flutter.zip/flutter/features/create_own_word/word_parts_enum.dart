enum WordParts { initialData, loadingData }
